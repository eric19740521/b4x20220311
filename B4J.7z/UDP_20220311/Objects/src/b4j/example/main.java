package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _button1 = null;
public static anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper _server = null;
public static anywheresoftware.b4a.objects.SocketWrapper.UDPSocket _udpsocket1 = null;
public static anywheresoftware.b4a.objects.SocketWrapper.UDPSocket _udpsocket2 = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _memo = null;
public static String _host = "";
public static anywheresoftware.b4a.objects.B4XViewWrapper _txtip = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _txtmsg = null;
public static anywheresoftware.b4a.objects.Timer _broadcasttimer = null;
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
 //BA.debugLineNum = 26;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 27;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 28;BA.debugLine="MainForm.RootPane.LoadLayout(\"Layout1\")";
_mainform.getRootPane().LoadLayout(ba,"Layout1");
 //BA.debugLineNum = 29;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 31;BA.debugLine="UDPSocket1.Initialize(\"UDPSocket1\", 5000, 8000)	'";
_udpsocket1.Initialize(ba,"UDPSocket1",(int) (5000),(int) (8000));
 //BA.debugLineNum = 32;BA.debugLine="UDPSocket2.Initialize(\"UDPSocket2\", 5100, 8000)	'";
_udpsocket2.Initialize(ba,"UDPSocket2",(int) (5100),(int) (8000));
 //BA.debugLineNum = 34;BA.debugLine="txtIP.Text = \"192.168.1.166\"";
_txtip.setText("192.168.1.166");
 //BA.debugLineNum = 38;BA.debugLine="BroadcastTimer.Initialize(\"BroadcastTimer\", DateT";
_broadcasttimer.Initialize(ba,"BroadcastTimer",(long) (anywheresoftware.b4a.keywords.Common.DateTime.TicksPerSecond*15));
 //BA.debugLineNum = 39;BA.debugLine="BroadcastTimer.Enabled=True";
_broadcasttimer.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return "";
}
public static String  _broadcasttimer_tick() throws Exception{
anywheresoftware.b4a.randomaccessfile.B4XSerializator _serializator = null;
String _address = "";
anywheresoftware.b4a.objects.SocketWrapper.UDPSocket.UDPPacket _up = null;
byte[] _data = null;
String _s = "";
 //BA.debugLineNum = 81;BA.debugLine="Private Sub BroadcastTimer_Tick";
 //BA.debugLineNum = 82;BA.debugLine="Log(\"BroadcastTimer_Tick==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("2524289","BroadcastTimer_Tick==>",0);
 //BA.debugLineNum = 83;BA.debugLine="Dim serializator As B4XSerializator";
_serializator = new anywheresoftware.b4a.randomaccessfile.B4XSerializator();
 //BA.debugLineNum = 84;BA.debugLine="Dim address As String = GetBroadcastAddress";
_address = _getbroadcastaddress();
 //BA.debugLineNum = 85;BA.debugLine="If address <> \"\" Then";
if ((_address).equals("") == false) { 
 //BA.debugLineNum = 86;BA.debugLine="Dim up As UDPPacket";
_up = new anywheresoftware.b4a.objects.SocketWrapper.UDPSocket.UDPPacket();
 //BA.debugLineNum = 88;BA.debugLine="Dim data() As Byte";
_data = new byte[(int) (0)];
;
 //BA.debugLineNum = 90;BA.debugLine="Dim s As String";
_s = "";
 //BA.debugLineNum = 91;BA.debugLine="s= \"主機:\"&Server.GetMyIP &\"對所有人廣播中...\"";
_s = "主機:"+_server.GetMyIP()+"對所有人廣播中...";
 //BA.debugLineNum = 92;BA.debugLine="data = s.GetBytes(\"UTF-8\")";
_data = _s.getBytes("UTF-8");
 //BA.debugLineNum = 93;BA.debugLine="up.Initialize(data, address, 5000)";
_up.Initialize(_data,_address,(int) (5000));
 //BA.debugLineNum = 94;BA.debugLine="UDPSocket2.Send(up)";
_udpsocket2.Send(_up);
 //BA.debugLineNum = 96;BA.debugLine="Log(\"廣播:\"&address)";
anywheresoftware.b4a.keywords.Common.LogImpl("2524303","廣播:"+_address,0);
 };
 //BA.debugLineNum = 98;BA.debugLine="End Sub";
return "";
}
public static String  _button1_click() throws Exception{
anywheresoftware.b4a.objects.SocketWrapper.UDPSocket.UDPPacket _packet = null;
byte[] _data = null;
 //BA.debugLineNum = 43;BA.debugLine="Sub Button1_Click";
 //BA.debugLineNum = 46;BA.debugLine="Dim Packet As UDPPacket";
_packet = new anywheresoftware.b4a.objects.SocketWrapper.UDPSocket.UDPPacket();
 //BA.debugLineNum = 47;BA.debugLine="Dim data() As Byte";
_data = new byte[(int) (0)];
;
 //BA.debugLineNum = 49;BA.debugLine="Host = txtIP.Text	'\"192.168.1.166\"";
_host = _txtip.getText();
 //BA.debugLineNum = 50;BA.debugLine="data = txtMsg.text.GetBytes(\"UTF8\")  '\"Hello from";
_data = _txtmsg.getText().getBytes("UTF8");
 //BA.debugLineNum = 51;BA.debugLine="Packet.Initialize(data, Host, 5100)";
_packet.Initialize(_data,_host,(int) (5100));
 //BA.debugLineNum = 52;BA.debugLine="UDPSocket2.Send(Packet)";
_udpsocket2.Send(_packet);
 //BA.debugLineNum = 54;BA.debugLine="txtMsg.text = \"\"";
_txtmsg.setText("");
 //BA.debugLineNum = 56;BA.debugLine="Log(\"Message sent: \" & BytesToString( data ,0,dat";
anywheresoftware.b4a.keywords.Common.LogImpl("2131085","Message sent: "+anywheresoftware.b4a.keywords.Common.BytesToString(_data,(int) (0),_data.length,"UTF-8"),0);
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return "";
}
public static String  _getbroadcastaddress() throws Exception{
anywheresoftware.b4j.object.JavaObject _niiterator = null;
anywheresoftware.b4j.object.JavaObject _ni = null;
anywheresoftware.b4a.objects.collections.List _addresses = null;
anywheresoftware.b4j.object.JavaObject _ia = null;
Object _broadcast = null;
String _b = "";
 //BA.debugLineNum = 101;BA.debugLine="Sub GetBroadcastAddress As String";
 //BA.debugLineNum = 102;BA.debugLine="Dim niIterator As JavaObject";
_niiterator = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 103;BA.debugLine="niIterator = niIterator.InitializeStatic(\"java.ne";
_niiterator = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_niiterator.InitializeStatic("java.net.NetworkInterface").RunMethod("getNetworkInterfaces",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 104;BA.debugLine="Do While niIterator.RunMethod(\"hasMoreElements\",";
while (BA.ObjectToBoolean(_niiterator.RunMethod("hasMoreElements",(Object[])(anywheresoftware.b4a.keywords.Common.Null)))) {
 //BA.debugLineNum = 105;BA.debugLine="Dim ni As JavaObject = niIterator.RunMethod(\"nex";
_ni = new anywheresoftware.b4j.object.JavaObject();
_ni = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_niiterator.RunMethod("nextElement",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 106;BA.debugLine="If ni.RunMethod(\"isLoopback\", Null) = False Then";
if ((_ni.RunMethod("isLoopback",(Object[])(anywheresoftware.b4a.keywords.Common.Null))).equals((Object)(anywheresoftware.b4a.keywords.Common.False))) { 
 //BA.debugLineNum = 107;BA.debugLine="Dim addresses As List = ni.RunMethod(\"getInterf";
_addresses = new anywheresoftware.b4a.objects.collections.List();
_addresses = (anywheresoftware.b4a.objects.collections.List) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.List(), (java.util.List)(_ni.RunMethod("getInterfaceAddresses",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 108;BA.debugLine="For Each ia As JavaObject In addresses";
_ia = new anywheresoftware.b4j.object.JavaObject();
{
final anywheresoftware.b4a.BA.IterableList group7 = _addresses;
final int groupLen7 = group7.getSize()
;int index7 = 0;
;
for (; index7 < groupLen7;index7++){
_ia = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(group7.Get(index7)));
 //BA.debugLineNum = 109;BA.debugLine="Dim broadcast As Object = ia.RunMethod(\"getBro";
_broadcast = _ia.RunMethod("getBroadcast",(Object[])(anywheresoftware.b4a.keywords.Common.Null));
 //BA.debugLineNum = 110;BA.debugLine="If broadcast <> Null Then";
if (_broadcast!= null) { 
 //BA.debugLineNum = 111;BA.debugLine="Dim b As String = broadcast";
_b = BA.ObjectToString(_broadcast);
 //BA.debugLineNum = 112;BA.debugLine="Return b.SubString(1)";
if (true) return _b.substring((int) (1));
 };
 }
};
 };
 }
;
 //BA.debugLineNum = 117;BA.debugLine="Return \"\"";
if (true) return "";
 //BA.debugLineNum = 118;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 8;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 9;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 10;BA.debugLine="Private Button1 As B4XView";
_button1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Private Server As ServerSocket";
_server = new anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Private UDPSocket1 As UDPSocket";
_udpsocket1 = new anywheresoftware.b4a.objects.SocketWrapper.UDPSocket();
 //BA.debugLineNum = 14;BA.debugLine="Private UDPSocket2 As UDPSocket";
_udpsocket2 = new anywheresoftware.b4a.objects.SocketWrapper.UDPSocket();
 //BA.debugLineNum = 16;BA.debugLine="Private Memo As B4XView";
_memo = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 18;BA.debugLine="Private Host As String";
_host = "";
 //BA.debugLineNum = 20;BA.debugLine="Private txtIP As B4XView";
_txtip = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Private txtMsg As B4XView";
_txtmsg = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 23;BA.debugLine="Private BroadcastTimer As Timer";
_broadcasttimer = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
public static String  _udpsocket1_packetarrived(anywheresoftware.b4a.objects.SocketWrapper.UDPSocket.UDPPacket _packet) throws Exception{
String _msg = "";
 //BA.debugLineNum = 60;BA.debugLine="Sub UDPSocket1_PacketArrived (Packet As UDPPacket)";
 //BA.debugLineNum = 62;BA.debugLine="Dim msg As String";
_msg = "";
 //BA.debugLineNum = 63;BA.debugLine="msg = BytesToString(Packet.Data, Packet.Offset, P";
_msg = anywheresoftware.b4a.keywords.Common.BytesToString(_packet.getData(),_packet.getOffset(),_packet.getLength(),"UTF8");
 //BA.debugLineNum = 64;BA.debugLine="Memo.Text = Memo.Text & Chr(13)&Chr(10)& Packet.H";
_memo.setText(_memo.getText()+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (13)))+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (10)))+_packet.getHost()+":"+_msg);
 //BA.debugLineNum = 66;BA.debugLine="Log(\"> NEW PACKET\")";
anywheresoftware.b4a.keywords.Common.LogImpl("2262150","> NEW PACKET",0);
 //BA.debugLineNum = 67;BA.debugLine="Log(\"Host: \"&Packet.Host)";
anywheresoftware.b4a.keywords.Common.LogImpl("2262151","Host: "+_packet.getHost(),0);
 //BA.debugLineNum = 68;BA.debugLine="Log(\"Adress: \"&Packet.HostAddress)";
anywheresoftware.b4a.keywords.Common.LogImpl("2262152","Adress: "+_packet.getHostAddress(),0);
 //BA.debugLineNum = 69;BA.debugLine="Log(\"Port: \"&Packet.Port)";
anywheresoftware.b4a.keywords.Common.LogImpl("2262153","Port: "+BA.NumberToString(_packet.getPort()),0);
 //BA.debugLineNum = 70;BA.debugLine="Log(\"Len: \"&Packet.Length)";
anywheresoftware.b4a.keywords.Common.LogImpl("2262154","Len: "+BA.NumberToString(_packet.getLength()),0);
 //BA.debugLineNum = 71;BA.debugLine="Log(\"ToString: \"&Packet.toString)";
anywheresoftware.b4a.keywords.Common.LogImpl("2262155","ToString: "+_packet.toString(),0);
 //BA.debugLineNum = 75;BA.debugLine="Log(\"Message received: \" & msg )";
anywheresoftware.b4a.keywords.Common.LogImpl("2262159","Message received: "+_msg,0);
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
return "";
}
}
